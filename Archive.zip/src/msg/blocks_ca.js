/**
 * @license
 * Copyright 2020 Carles Ferrando Garcia (ferrando_cariga@gva.es)
 * SPDX-License-Identifier: BSD-3-Clause
 */

const blocks_ca = {

    "msg" : [{

        //text in blocks
        "FIELDDROPDOWN" : [["1 (activat)", "HIGH"], ["0 (desactivat)", "LOW"]],
        "FIELDDROPDOWN_ONOFF" : [["turn on", "ON"], ["turn off", "OFF"]],
        "FIELDDROPDOWN_ONOFF2" : [["switch on", "HIGH"], ["switch off", "LOW"]],
        "FIELDDROPDOWN_ONOFF3" : [["close", "HIGH"], ["open", "LOW"]],
        
        //blockly logic
        "CONTROLS_SWITCH_CASEBREAK_TOOLTIP" : "Afegeix una condició al bloc de «casos».",
        "CONTROLS_SWITCH_DEFAULT_TOOLTIP" : "Afegeix una condició final per defecte.",
        "CONTROLS_SWITCH_HELPURL" : "https://en.wikipedia.org/wiki/Switch_statement",
        "CONTROLS_SWITCH_SWITCH_TOOLTIP" : "Afegeix, retira, o classifica les seccions d'aquest bloc.",
        "CONTROLS_SWITCH_VAR_TITLE" : "selecciona ( ",
        "CONTROLS_SWITCH_VAR_TAIL" : ")",
        "CONTROLS_SWITCH_MSG_DEFAULT" : "per defecte",
        "CONTROLS_SWITCH_MSG_CASEBREAK" : "cas",
        "CONTROLS_SWITCH_MSG_SWITCHVAR" : "Selecciona (var)",
        "CONTROLS_SWITCH_MSG_DO" : "fes",
        "CONTROLS_SWITCH_TOOLTIP_1" : "Si el valor és cert llavors executa les ordres següents.",
        "CONTROLS_SWITCH_TOOLTIP_2" : "Si el valor és cert executa el primer bloc d'ordres. En cas contrari executa el bloc següent d'ordres.",
        "CONTROLS_SWITCH_TOOLTIP_3" : "Si el valor és cert executa el primer bloc d'ordres. En cas contrari executa el bloc següent d'ordres si la condició és certa.",
        "CONTROLS_SWITCH_TOOLTIP_4" : "Si el valor és cert executa el primer bloc d'ordres. En cas contrari executa el bloc següent d'ordres si la condició és certa. Si ninguna condició és verifica, llavors executa el darrer bloc d'ordres per defecte.",
        "CONTROLS_SWITCH_VAR_TOOLTIP" : "Desplaça el bloc des de l'esquerra per afegir-lo.",
        "CONTROLS_SWITCH_CASEBREAK_TOOLTIP" : "Afegeix un bloc d'ordres cas trenca",
        "CONTROLS_SWITCH_DEFAULT_TOOLTIP" : "Afegeix un bloc d'accions per defecte",
        //Arduino base cateory blocks
        "VAR_CREATE_INT" : "integer",
        "VAR_CREATE_FLOAT" : "float",
        "VAR_CREATE_STRING" : "string",
        "VAR_CREATE_BOOLEAN" : "boolean",
        "ARDUINO_INOUT_BUILDIN_LED_HELPURL" : "http://arduino.cc/en/Reference/DigitalWrite",
        "ARDUINO_INOUT_BUILDIN_LED_INPUT" : "posa el LED a l'estat lògic",
        "ARDUINO_INOUT_BUILDIN_LED_TOOLTIP" : "atura o engega el LED a la placa Arduino",
        "ARDUINO_INOUT_DIGITAL_WRITE_INPUT1" : "posa el pin digital",
        "ARDUINO_INOUT_DIGITAL_WRITE_INPUT2" : "a l'estat lògic",
        "ARDUINO_INOUT_DIGITAL_WRITE_TOOLTIP" : "escriu un valor (0 ou 1) al pin triat a la sortida",
        "ARDUINO_INOUT_DIGITAL_WRITE_HELPURL" : "http://arduino.cc/en/Reference/DigitalWrite",
        "ARDUINO_INOUT_DIGITAL_READ_INPUT" : "l'estat lògic del pin nº",
        "ARDUINO_INOUT_DIGITAL_READ_TOOLTIP" : "llegeix el valor (0 o 1) al pin triat a l'entrada",
        "ARDUINO_INOUT_DIGITAL_READ_HELPURL" : "http://arduino.cc/en/Reference/DigitalRead",
        "ARDUINO_INOUT_ONOFF_HELPURL" : "http://arduino.cc/en/Reference/Constants",
        "ARDUINO_INOUT_ANALOG_WRITE_INPUT1" : "write about Analog pin",
        "ARDUINO_INOUT_ANALOG_WRITE_INPUT2" : "value",
        "ARDUINO_INOUT_ANALOG_WRITE_TOOLTIP" : "escriu un valor (comprés entre 0 i 255) al pin analògic.\nATENCIÓ: Verifiqueu que el pin sigui PWM~ !",
        "ARDUINO_INOUT_ANALOG_WRITE_HELPURL" : "http://arduino.cc/en/Reference/AnalogWrite",
        "ARDUINO_INOUT_ANALOG_READ_INPUT" : "el valor llegit al pin d'entrada analògica",
        "ARDUINO_INOUT_ANALOG_READ_TOOLTIP" : "llegeix el valor (comprés entre 0 i 1023) al pin analògics.\nATENCIÓ: Verifiqueu que el pin sigui A# (exemple : A0,A1,...)",
        "ARDUINO_INOUT_ANALOG_READ_HELPURL" : "http://arduino.cc/en/Reference/AnalogRead",
        "ARDUINO_BASE_DELAY_DELAY_TIME" : "fes una temporització (en ms) de",
        "ARDUINO_BASE_DELAY_TOOLTIP" : "especifica el temps d'espera, atura l'execució del programa el temps indicat",
        "ARDUINO_BASE_DELAY_HELPURL" : "http://arduino.cc/en/Reference/delay",
        "ARDUINO_BASE_ANGLE" : "angle de: ",
        "ARDUINO_BASE_ANGLE_TOOLTIP" : "angle té un valor entre 0~180°",
        "ARDUINO_BASE_ANGLE_HELPURL" : "",
        "ARDUINO_BASE_MAP1" : "map",
        "ARDUINO_BASE_MAP2" : "value to [0-",
        "ARDUINO_BASE_MAP_TOOLTIP" : "Re-maps a number from [0-1024] to another.",
        "ARDUINO_BASE_MAP_HELPURL" : "https://www.arduino.cc/reference/en/language/functions/math/map/",
        "ARDUINO_TONE_INPUT1" : "emet un só al pin",
        "ARDUINO_TONE_INPUT2" : "d'una freqüència (Hz)",
        "ARDUINO_TONE_TOOLTIP" : "emet un só al pin seleccionat",
        "ARDUINO_TONE_HELPURL" : "http://arduino.cc/en/Reference/AnalogWrite",
        "ARDUINO_NOTONE_INPUT" : "atura el só al pin",
        "ARDUINO_NOTONE_TOOLTIP" : "atura el só al pin seleccionat",
        "ARDUINO_NOTONE_HELPURL" : "http://arduino.cc/en/Reference/AnalogWrite",

        //SERIAL
        "SERIAL_PRINT_FORMAT" : "imprimeix en format",
        "SERIAL_PRINT_FORDECIMAL" : "decimal",
        "SERIAL_PRINT_FORHEXA" : "hexadecimal",
        "SERIAL_PRINT_FORBIN" : "binari",
        "SERIAL_PRINT_FOROCT" : "byte",
        "SERIAL_READ" : "llegeix el sèrie",
        "SERIAL_AVAILABLE" : "està disponible una dada al sèrie ?",
        "SERIAL_FLUSH" : "espera fi de transmisió al sèrie",
        "SERIAL_READSTRINGUNTIL_HELPURL" : "https://www.arduino.cc/en/Serial/ReadStringUntil",
        "SERIAL_READSTRINGUNTIL_CONTENT" : "cadena llegida fins al caràcter",
        "SERIAL_READSTRINGUNTIL_TOOLTIP" : "llegeix els caràcters un per un al cercat, i retorna tota la cadena de caràcters",
        "SERIAL_PRINT_CONTENT" : "envia el text al port sèrie:",
        "SERIAL_PRINT_TOOLTIP" : "envia dades al port sèrie per a vigilancia amb el monitor ASCII",
        "SERIAL_PRINT_HELPURL" : "http://www.arduino.cc/en/Serial/Print",

        //Arduino base servo category blocks
        "SERVO_MOVE_TOOLTIP" : "rotació posible entre 0~180 graus",
        "SERVO_MOVE_HELPURL" : "http://www.arduino.cc/playground/ComponentLib/servo",
        "SERVO_PIN" : "PIN#",
        "SERVO_MOVE_INPUT" : "rota el servomotor",
        "SERVO_MOVE_DEGREE" : "d'un angle (0~180°)",
        "SERVO_READ_DEGREES_INPUT" : "l'angle del servomotor",
        "SERVO_READ_DEGREES_TOOLTIP" : "retorna el nombre de graus de la darrera rotació",
        "SERVO_READ_DEGREES_HELPURL" : "http://www.arduino.cc/playground/ComponentLib/servo",

        //X-NUCLEO-IKS01A3 shield blocks: the X-NUCLEO-IKS01A3 is a motion MEMS and environmental sensor evaluation board system, for ST Nucleo boards.
        "X_NUCLEO_IKS01A3_Temp_Read_INPUT" : "onboard temperature sensor value",
        "X_NUCLEO_IKS01A3_Temp_Read_TOOLTIP" : "HTS221: capacitive digital temperature in °Celsius",
        "X_NUCLEO_IKS01A3_Temp_Read_HELPURL" : "onboard temperature sensor value",
        "X_NUCLEO_IKS01A3_Humidity_Read_INPUT" : "onboard humidity sensor value",
        "X_NUCLEO_IKS01A3_Humidity_Read_TOOLTIP" : "HTS221: capacitive digital relative humidity in percent",
        "X_NUCLEO_IKS01A3_Humidity_Read_HELPURL" : "https://www.st.com/en/ecosystems/x-nucleo-iks01a3.html",

        //DS18B20 sensors
        "DS18B20_TEXT1" : "a DS18B20 sensor",
        "DS18B20_INPUT1" : "is connected on pin#",
        "DS18B20_INPUT2" : "address #",
        "DS18B20_TOOLTIP1" : "test if a DS18B20 temperature sensor is present, returns 'true' if present",
        "DS18B20_HELPURL" : "https://www.carnetdumaker.net/articles/mesurer-une-temperature-avec-un-capteur-1-wire-ds18b20-et-une-carte-arduino-genuino/",
        "DS18B20_TEXT2" : "sensor DS18B20 value",
        "DS18B20_TOOLTIP2" : "returns the value of the temperature sensor, as a floating number",

        //Relays actuators
        "RELAY_LOGICAL_TEXT" : "relay",
        "RELAY_LOGICAL_INPUT" : "on pin#",
        "RELAY_LOGICAL_TOOLTIP" : "the relay is a remote switch, it is a switch placed in a power circuit which is switched by a digital signal",
        "RELAY_LOGICAL_HELPURL" : "https://arduinogetstarted.com/tutorials/arduino-relay",
        "RELAY_MOSFET_TEXT" : "MOSFET transistor",
        "RELAY_MOSFET_INPUT" : "on pin#",
        "RELAY_MOSFET_TOOLTIP" : "the MOSFET transistor is a remote switch, a switch in a power circuit that is switched by a digital signal",
        "RELAY_MOSFET_HELPURL" : "http://sin.lyceeleyguescouffignal.fr/irf520-mosfet-driver-module",

}]
}

export default blocks_ca