/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import {Order} from 'blockly/javascript';

import dropdownDigitalMotor from "../arduinoMega/sensor_motor3";

// Export all the code generators for our custom blocks,
// but don't register them with Blockly yet.
// This file has no side effects!
export const forBlock = Object.create(null);

forBlock['add_text'] = function (block, generator) {
  const text = generator.valueToCode(block, 'TEXT', Order.NONE) || "''";
  const color =
    generator.valueToCode(block, 'COLOR', Order.ATOMIC) || "'#ffffff'";

  const addText = generator.provideFunction_(
      'addText',
      `function ${generator.FUNCTION_NAME_PLACEHOLDER_}(text, color) {

  // Add text to the output area.
  const outputDiv = document.getElementById('output');
  const textEl = document.createElement('p');
  textEl.innerText = text;
  textEl.style.color = color;
  outputDiv.appendChild(textEl);
}`
  );
  // Generate the function call for this block.
  const code = `${addText}(${text}, ${color});\n`;
  return code;
};


  forBlock['ultrasonic_sensor'] = function(block, generator) {
    var dropdown_sensor = block.getFieldValue('sensor');
  
    // TODO: Assemble javascript into code variable.
    var code = '...';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, generator.ORDER_NONE];
  };

  forBlock['IR_Sensor'] = function(block, generator) {
    var dropdown_sensor = block.getFieldValue('sensor');
  
    // TODO: Assemble javascript into code variable.
    var code = '...';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, generator.ORDER_NONE];
  };

  forBlock['sensor3'] = function(block, generator) {
    var dropdown_sensor = block.getFieldValue('sensor');
  
    // TODO: Assemble javascript into code variable.
    var code = '...';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, generator.ORDER_NONE];
  };

  forBlock['sensor4'] = function(block, generator) {
    var dropdown_sensor = block.getFieldValue('sensor');

    
    // TODO: Assemble javascript into code variable.
    var code = '...';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, generator.ORDER_NONE];
  };

  forBlock['sensor5'] = function(block, generator) {
    var dropdown_sensor = block.getFieldValue('sensor');
  
    // TODO: Assemble javascript into code variable.
    var code = '...';
    // TODO: Change ORDER_NONE to the correct strength.
    return [code, generator.ORDER_NONE];
  };


  forBlock['motor'] = function(block, generator) {
    var field_name = block.getFieldValue('NAME');
    var dropdown_name1 = block.getFieldValue('NAME1');
    var dropdown_name2 = block.getFieldValue('NAME2');

    
    // Generate setup for both pins of M1
    generator.provideFunction_(`setup_output_${dropdown_name1}`, `pinMode(${dropdown_name1}, OUTPUT);`);
    generator.provideFunction_(`setup_output_${dropdown_name1}`, `pinMode(${dropdown_name1}, OUTPUT);`);
    
    // Generate code for writing to both pins of M1
    var code = `digitalWrite(${dropdown_name1}, ${dropdown_name2});\n`;
  //  code += `digitalWrite(${dropdown_name1[2]}, ${dropdown_name2}, ${dropdown_name3});\n`;
    
    return code;
  };

  forBlock['motor2'] = function(block, generator) {
    var field_name = block.getFieldValue('NAME');
    var dropdown_name1 = block.getFieldValue('NAME1');
    var dropdown_name2 = block.getFieldValue('NAME2');
    
    // Generate setup for both pins of M1
    generator.provideFunction_(`setup_output_${dropdown_name1}`, `pinMode(${dropdown_name1}, OUTPUT);`);
    generator.provideFunction_(`setup_output_${dropdown_name1}`, `pinMode(${dropdown_name1}, OUTPUT);`);
    
    // Generate code for writing to both pins of M1
    var code = `digitalWrite(${dropdown_name1}, ${dropdown_name2});\n`;
  //  code += `digitalWrite(${dropdown_name1[2]}, ${dropdown_name2}, ${dropdown_name3});\n`;
    
    return code;
  };

  forBlock['motor3'] = function(block, generator) {
    var field_name = block.getFieldValue('NAME');
    var dropdown_name1 = block.getFieldValue('NAME1');
    var dropdown_name2 = block.getFieldValue('NAME2');

    
    // Generate setup for both pins of M1
    generator.provideFunction_(`setup_output_${dropdown_name1}`, `pinMode(${dropdown_name1}, OUTPUT);`);
    generator.provideFunction_(`setup_output_${dropdown_name1}`, `pinMode(${dropdown_name1}, OUTPUT);`);
    
    // Generate code for writing to both pins of M1
    var code = `digitalWrite(${dropdown_name1}, ${dropdown_name2});\n`;
  //  code += `digitalWrite(${dropdown_name1[2]}, ${dropdown_name2}, ${dropdown_name3});\n`;
    
    return code;
  };

  forBlock['motor4'] = function(block, generator) {
    var field_name = block.getFieldValue('NAME');
    var dropdown_name1 = block.getFieldValue('NAME1');
    var dropdown_name2 = block.getFieldValue('NAME2');
   
    
    // Generate setup for both pins of M1
    generator.provideFunction_(`setup_output_${dropdown_name1}`, `pinMode(${dropdown_name1}, OUTPUT);`);
    generator.provideFunction_(`setup_output_${dropdown_name1}`, `pinMode(${dropdown_name1}, OUTPUT);`);
    
    // Generate code for writing to both pins of M1
    var code = `digitalWrite(${dropdown_name1}, ${dropdown_name2});\n`;
  //  code += `digitalWrite(${dropdown_name1[2]}, ${dropdown_name2}, ${dropdown_name3});\n`;
    
    return code;
  };

  forBlock['motor5'] = function(block, generator) {
    var field_name = block.getFieldValue('NAME');
    var dropdown_name1 = block.getFieldValue('NAME1');
    var dropdown_name3 = block.getFieldValue('NAME3');
    
    // Generate setup for both pins of M1
    generator.provideFunction_(`setup_output_${dropdown_name1}`, `pinMode(${dropdown_name1}, OUTPUT);`);
    generator.provideFunction_(`setup_output_${dropdown_name1}`, `pinMode(${dropdown_name1}, OUTPUT);`);
    
    // Generate code for writing to both pins of M1
    var code = `digitalWrite(${dropdown_name1}, ${dropdown_name3});\n`;
  //  code += `digitalWrite(${dropdown_name1[2]}, ${dropdown_name2}, ${dropdown_name3});\n`;
    
    return code;
  };
  
  
  
  
  
  forBlock['board_base_inout_buildin_led'] = function (block, generator) {
    var dropdown_stat = block.getFieldValue('STAT');
    
    // Setup for pin 13
    generator.provideFunction_('setup_output_13', 'pinMode(LED_BUILTIN, OUTPUT);');
    // Setup for pin 14
    //generator.provideFunction_('setup_output_14', 'pinMode(14, OUTPUT);');

    // Digital write for pin 13
    const code = `digitalWrite(LED_BUILTIN, ${dropdown_stat});\n`;

    // Digital write for pin 14 (you can modify this line as needed)
   // const code14 = `digitalWrite(14, ${dropdown_stat});\n`;

    return code // + code14;
};

  forBlock['board_base_inout_digital_write'] = function (block, generator) {
    var dropdown_pin = block.getFieldValue('PIN');
    var dropdown_stat = block.getFieldValue('STAT');
    
    generator.provideFunction_(`setup_output_${dropdown_pin}`, `pinMode(${dropdown_pin}, OUTPUT);`);
    
    const code = `digitalWrite(${dropdown_pin}, ${dropdown_stat});\n`;
    return code;
  };


forBlock['board_base_inout_digital_read'] = function (block, generator) {
  var dropdown_pin = block.getFieldValue('PIN');
  
  generator.provideFunction_(`setup_input_${dropdown_pin}`, `pinMode(${dropdown_pin}, INPUT);`);
  
  const code = `digitalRead(${dropdown_pin})`;
  return [code, generator.ORDER_ATOMIC];
};

forBlock['board_base_inout_highlow'] = function (block, generator) {
  // Boolean values HIGH and LOW.
  const code = block.getFieldValue('BOOL') === 'HIGH' ? 'HIGH' : 'LOW';
  return [code, generator.ORDER_ATOMIC];
};

forBlock['board_base_inout_analog_write'] = function (block, generator) {
  var dropdown_pin = block.getFieldValue('PIN');
  var value_num = generator.valueToCode(this, 'PWM', generator.ORDER_ATOMIC);
  
  // Assuming there's no need for setup since it's commented out in the original code
  // generator.setupOutput(`setup_output_${dropdown_pin}`, `pinMode(${dropdown_pin}, OUTPUT);`);
  
  const code = `analogWrite(${dropdown_pin}, ${value_num});\n`;
  return code;
};

forBlock['board_base_inout_analog_read'] = function (block, generator) {
  var dropdown_pin = block.getFieldValue('PIN');
  
  // Assuming there's no need for setup since it's commented out in the original code
  // generator.setupInput(`setup_input_${dropdown_pin}`, `pinMode(${dropdown_pin}, INPUT);`);
  
  const code = `analogRead(${dropdown_pin})`;
  return [code, generator.ORDER_ATOMIC];
};

forBlock['board_base_delay'] = function (block, generator) {
  var delay_time = generator.valueToCode(this, 'DELAY_TIME', generator.ORDER_ATOMIC) || '1000';
  const code = `delay(${delay_time});\n`;
  return code;
};

forBlock['board_base_angle'] = function (block, generator) {
  var angle = block.getFieldValue('ANGLE');
  return [angle, generator.ORDER_ATOMIC];
};

forBlock['board_base_map'] = function (block, generator) {
  var value_num = generator.valueToCode(this, 'NUM', generator.ORDER_NONE);
  var value_dmax = generator.valueToCode(this, 'DMAX', generator.ORDER_ATOMIC);
  const code = `map(${value_num}, 0, 1024, 0, ${value_dmax})`;
  return [code, generator.ORDER_NONE];
};


forBlock['board_base_inout_tone'] = function (block, generator) {
  var dropdown_pin = block.getFieldValue('PIN');
  var value_num = generator.valueToCode(this, 'NUM', generator.ORDER_ATOMIC);

  generator.provideFunction_(`setup_output${dropdown_pin}`, `pinMode(${dropdown_pin}, OUTPUT);`);
  
  const code = `tone(${dropdown_pin}, ${value_num});\n`;
  return code;
};


forBlock['board_base_inout_notone'] = function (block, generator) {
  var dropdown_pin = block.getFieldValue('PIN');

  generator.provideFunction_(`setup_output${dropdown_pin}`, `pinMode(${dropdown_pin}, OUTPUT);`);
  
  const code = `noTone(${dropdown_pin});\n`;
  return code;
};


// serial_block defition do this by tomarrow :)


forBlock['board_serial_init'] = function (block, generator) {
  var dropdown_speed = block.getFieldValue('SPEED');
  generator.provideFunction_(`serial_begin`, `Serial.begin(${dropdown_speed});`);
  
  const code = '';
  return code;
};

forBlock['board_serial_printfor'] = function (block, generator) {
  var content = generator.valueToCode(block, 'CONTENT', generator.ORDER_NONE);
  var type = block.getFieldValue('TYPE');

  generator.provideFunction_('serial_println', `Serial.println(${content}, ${type});`);

  const code = '';
  return code;
};

forBlock['board_serial_print'] = function (block, generator) {
  var content = generator.valueToCode(block, 'CONTENT', generator.ORDER_ATOMIC) || '0';

  generator.provideFunction_('serial_println', `Serial.println(${content});`);

  const code = '';
  return code;
};

forBlock['board_serial_available'] = function (block, generator) {
  const code = 'Serial.available()';
  return [code, generator.ORDER_ATOMIC];
};

forBlock['board_serial_read'] = function (block, generator) {
  const code = 'Serial.read()';
  return [code, generator.ORDER_ATOMIC];
};

forBlock['board_serial_readStringUntil'] = function (block, generator) {
  var content = generator.valueToCode(block, 'CONTENT', generator.ORDER_NONE);
  content = content.replace(/"/g, "'");  // Replace all double quotes with single quotes
  const code = `Serial.readStringUntil(${content})`;
  return [code, generator.ORDER_ATOMIC];
};

forBlock['board_serial_flush'] = function (block, generator) {
  const code = 'Serial.flush();\n';
  return code;
};






