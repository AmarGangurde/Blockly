/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import * as Blockly from 'blockly/core';
import profile from '../arduinoMega/profile';
import blocks_ar from '../msg/blocks_ar'
import blocks_ca from '../msg/blocks_ca'
import sensor_motor from '../arduinoMega/sensor_motor'
import sensor_sensor from '../arduinoMega/sensor_sensor'
import sensor_motor2 from '../arduinoMega/sensor_motor2'
import sensor_motor3 from '../arduinoMega/sensor_motor3'
import sensor_motor4 from '../arduinoMega/sensor_motor4'
import sensor_motor5 from '../arduinoMega/sensor_motor5'

const motorSensor4 = sensor_motor4
const motorSensor5 = sensor_motor5
const motorSensor3 = sensor_motor3
const motorSensor2 = sensor_motor2 
const motorSensor = sensor_motor
const sensor = sensor_sensor

//this msgOptions taking value from block_ar.js
const msgOptions = blocks_ar.hello[0];
const msgOptions2 = blocks_ca.msg[0];

// this arduinoMegaBoard taking valur from profile.js 

const arduinoMegaBoard = profile.arduino_mega[0];

// Now you can use arduinoMegaBoard in the relevant sections of your code.
// For example, you can access dropdownDigital like this:
const I2C = arduinoMegaBoard.I2C
const PWM = arduinoMegaBoard.PWM
const SPI = arduinoMegaBoard.SPI
const _id = arduinoMegaBoard._id
const analog = arduinoMegaBoard.analog
const cpu = arduinoMegaBoard.cpu
const description = arduinoMegaBoard.description
const digital = arduinoMegaBoard.digital
const dropdownAnalog = arduinoMegaBoard.dropdownAnalog
const dropdownDigitalOptions = arduinoMegaBoard.dropdownDigital;
const dropdownPWM = arduinoMegaBoard.dropdownPWM
const interrupt = arduinoMegaBoard.interrupt
const picture = arduinoMegaBoard.picture
const serial = arduinoMegaBoard.serial
const serialList = arduinoMegaBoard.serialList
const serialPin = arduinoMegaBoard.serialPin
const speed = arduinoMegaBoard.speed
const upload_arg = arduinoMegaBoard.upload_arg

// Create a custom block called 'add_text' that adds
// text to the output div on the sample app.
// This is just an example and you should replace this with your
// own custom blocks.
const addText = {
  'type': 'add_text',
  'message0': 'Add text %1 with color %2',
  'args0': [
    {
      'type': 'input_value',
      'name': 'TEXT',
      'check': 'String',
    },
    {
      'type': 'input_value',
      'name': 'COLOR',
      'check': 'Colour',
    },
  ],
  'previousStatement': null,
  'nextStatement': null,
  'colour': 160,
  'tooltip': '',
  'helpUrl': '',
};

const ultrasonic_sensor = {
  "type": "ultrasonic_sensor",
  "message0": "%1 %2 %3",
  "args0": [
    {
      "type": "field_label_serializable",
      "name": "",
      "text": "Read_Ultrasonic_Sensor_At"
    },
    {
      "type": "field_dropdown",
      "name": "sensor",
      "options": sensor
    },
    {
      "type": "input_end_row"
    }
  ],
  "output": null,
  "colour": 300,
  "tooltip": "",
  "helpUrl": ""
}

const ir_Sensor = {

  "type": "IR_Sensor",
  "message0": "%1 %2 %3",
  "args0": [
    {
      "type": "field_label_serializable",
      "name": "",
      "text": "Read_IR_Sensor_At"
    },
    {
      "type": "field_dropdown",
      "name": "sensor",
      "options": sensor
    },
    {
      "type": "input_end_row"
    }
  ],
  "output": null,
  "colour": 300,
  "tooltip": "",
  "helpUrl": ""
}

const sensor3 = {
  "type": "sensor3",
  "message0": "%1 %2 %3",
  "args0": [
    {
      "type": "field_label_serializable",
      "name": "",
      "text": "Read_Sensor3_Sensor_At"
    },
    {
      "type": "field_dropdown",
      "name": "sensor",
      "options": sensor
    },
    {
      "type": "input_end_row"
    }
  ],
  "output": null,
  "colour": 300,
  "tooltip": "",
  "helpUrl": ""
};

const sensor4 = {
  "type": "sensor4",
  "message0": "%1 %2 %3",
  "args0": [
    {
      "type": "field_label_serializable",
      "name": "",
      "text": "Read_Sensor4_Sensor_At"
    },
    {
      "type": "field_dropdown",
      "name": "sensor",
      "options": sensor
    },
    {
      "type": "input_end_row"
    }
  ],
  "output": null,
  "colour": 300,
  "tooltip": "",
  "helpUrl": ""
}

const sensor5 = {
  "type": "sensor5",
  "message0": "%1 %2 %3",
  "args0": [
    {
      "type": "field_label_serializable",
      "name": "",
      "text": "Read_Sensor5_Sensor_At"
    },
    {
      "type": "field_dropdown",
      "name": "sensor",
      "options": sensor
    },
    {
      "type": "input_end_row"
    }
  ],
  "output": null,
  "colour": 300,
  "tooltip": "",
  "helpUrl": ""
};

const motor = {  
  "type": "motor",
  "message0": "%1 %2 %3 %4 ",
  "args0": [
    {
      "type": "field_label_serializable",
      "name": "NAME",
      "text": "MOTOR I/P 1 "
    },
    {
      "type": "field_dropdown",
      "name": "NAME1",
      "options": motorSensor
    },
    {
      "type": "field_dropdown",
      "name": "NAME2",
      "options": [
        [
          "HIGH",
          "HIGH"
        ],
        [
          "LOW",
          "LOW"
        ],
      ]
    },
    {
      "type": "input_end_row"
    }
  ],
  "previousStatement": null,
  "nextStatement": null,
  "colour": 230,
  "tooltip": "",
  "helpUrl": ""
};

const motor2 = {  
  "type": "motor2",
  "message0": "%1 %2 %3 %4",
  "args0": [
    {
      "type": "field_label_serializable",
      "name": "NAME",
      "text": "MOTOR I/P 2 "
    },
    {
      "type": "field_dropdown",
      "name": "NAME1",
      "options": motorSensor2
    },
    {
      "type": "field_dropdown",
      "name": "NAME2",
      "options": [
        [
          "HIGH",
          "HIGH"
        ],
        [
          "LOW",
          "LOW"
        ],
      ]
    },
    {
      "type": "input_end_row"
    }
  ],
  "previousStatement": null,
  "nextStatement": null,
  "colour": 230,
  "tooltip": "",
  "helpUrl": ""
};

const motor3 = {  
  "type": "motor3",
  "message0": "%1 %2 %3 %4",
  "args0": [
    {
      "type": "field_label_serializable",
      "name": "NAME",
      "text": "POWER MOTOR I/P 1 "
    },
    {
      "type": "field_dropdown",
      "name": "NAME1",
      "options": motorSensor3
    },
    {
      "type": "field_dropdown",
      "name": "NAME2",
      "options": [
        [
          "HIGH",
          "HIGH"
        ],
        [
          "LOW",
          "LOW"
        ],
       
      ]
    },
    {
      "type": "input_end_row"
    }
  ],
  "previousStatement": null,
  "nextStatement": null,
  "colour": 230,
  "tooltip": "",
  "helpUrl": ""
};

const motor4 = {  
  "type": "motor4",
  "message0": "%1 %2 %3 %4",
  "args0": [
    {
      "type": "field_label_serializable",
      "name": "NAME",
      "text": "POWER MOTOR I/P 2"
    },
    {
      "type": "field_dropdown",
      "name": "NAME1",
      "options": motorSensor4
    },
    {
      "type": "field_dropdown",
      "name": "NAME2",
      "options": [
        [
          "HIGH",
          "HIGH"
        ],
        [
          "LOW",
          "LOW"
        ],
      ]
    },
    {
      "type": "input_end_row"
    }
  ],
  "previousStatement": null,
  "nextStatement": null,
  "colour": 230,
  "tooltip": "",
  "helpUrl": ""
};

const motor5 = {  
  "type": "motor5",
  "message0": "%1 %2 %3 %4",
  "args0": [
    {
      "type": "field_label_serializable",
      "name": "NAME",
      "text": "POWER MOTOR SPEED "
    },
    {
      "type": "field_dropdown",
      "name": "NAME1",
      "options": motorSensor5
    },
    {
      "type": "field_dropdown",
      "name": "NAME3",
      "options": [
        [
          "High",
          "High"
        ],
        [
          "Medium",
          "Medium"
        ],
        [
          "Low",
          "Low"
        ]
      ]
    },
    {
      "type": "input_end_row"
    }
  ],
  "previousStatement": null,
  "nextStatement": null,
  "colour": 230,
  "tooltip": "",
  "helpUrl": ""
};

const board_base_inout_buildin_led =  {
  "type": "board_base_inout_buildin_led",
  "message0": "Put LED on Card %1",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "STAT",
      "options": [
        ["HIGH", "HIGH"],
        ["LOW", "LOW"]
      ]
    }
  ],
  "previousStatement": null,
  "nextStatement": null,
  "tooltip": "%{BKY_ARDUINO_INOUT_BUILDIN_LED_TOOLTIP}",
  "helpUrl": "%{BKY_ARDUINO_INOUT_BUILDIN_LED_HELPURL}",
  "style": "arduino_blocks"
};

const board_base_inout_digital_write = {
  "type": "board_base_inout_digital_write",
  "message0": "put the pin digit %1 to logic state  %2 ",
  "args0": [
   
    {
      "type": "field_dropdown",
      "name": "PIN",
      "options": dropdownDigitalOptions
    },
    {
      "type": "field_dropdown",
      "name": "STAT",
      "options": msgOptions.FIELDDROPDOWN
    }
  ],
  "previousStatement": null,
  "nextStatement": null,
  "tooltip": "%{BKY_ARDUINO_INOUT_DIGITAL_WRITE_TOOLTIP}",
  "helpUrl": "%{BKY_ARDUINO_INOUT_DIGITAL_WRITE_HELPURL}",
  "style": "arduino_blocks"
};

const board_base_inout_digital_read = {
  "type": "board_base_inout_digital_read",
  "message0": "logic state of the pin #%1",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "PIN",
      "options": dropdownDigitalOptions
    }
  ],
  "output": "Boolean",
  "tooltip": "%{BKY_ARDUINO_INOUT_DIGITAL_READ_TOOLTIP}",
  "helpUrl": "%{BKY_ARDUINO_INOUT_DIGITAL_READ_HELPURL}",
  "style": "arduino_blocks"
};

const board_base_inout_highlow = {
  "type": "board_base_inout_highlow",
  "message0": "%1",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "BOOL",
      "options": msgOptions.FIELDDROPDOWN
    }
  ],
  "output": "Boolean",
  "tooltip": msgOptions.LOGIC_BOOLEAN_TOOLTIP,
  "helpUrl": msgOptions.ARDUINO_INOUT_ONOFF_HELPURL,
  "style": "arduino_blocks"
};

const board_base_inout_analog_write = {
  "type": "board_base_inout_analog_write",
  "message0": "Write about analog pin %1 value %2",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "PIN",
      "options": dropdownPWM
    },
    {
      "type": "input_value",
      "name": "PWM",
      "check": "Number"
    }
  ],
  "inputsInline": true,
  "previousStatement": null,
  "nextStatement": null,
  "tooltip": msgOptions.ARDUINO_INOUT_ANALOG_WRITE_TOOLTIP,
  "helpUrl": msgOptions.ARDUINO_INOUT_ANALOG_WRITE_HELPURL,
  "style": "arduino_blocks"
};

const board_base_inout_analog_read = {
  "type": "board_base_inout_analog_read",
  "message0": " read value on a analog input %1",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "PIN",
      "options": dropdownAnalog
    }
  ],
  "output": "int",
  "tooltip": msgOptions.ARDUINO_INOUT_ANALOG_READ_TOOLTIP,
  "helpUrl": msgOptions.ARDUINO_INOUT_ANALOG_READ_HELPURL,
  "style": "arduino_blocks"
};

const board_base_delay = {
  "type": "board_base_delay",
  "message0": "Delay in Ms %1",
  "args0": [
    {
      "type": "input_value",
      "name": "DELAY_TIME",
      "check": "Number"
    },
  ],
  "inputsInline": true,
  "previousStatement": null,
  "nextStatement": null,
  "tooltip": msgOptions.ARDUINO_BASE_DELAY_TOOLTIP,
  "helpUrl": msgOptions.ARDUINO_BASE_DELAY_HELPURL,
  "style": "arduino_blocks"
};

const board_base_angle = {
  "type": "board_base_angle",
  "message0": "Angle : %1",
  "args0": [
    {
      "type": "field_angle",
      "name": "ANGLE",
      "angle": 90
    },
  ],
  "output": String,
  "tooltip": msgOptions.ARDUINO_BASE_ANGLE_TOOLTIP,
  "helpUrl": msgOptions.ARDUINO_BASE_ANGLE_HELPURL,
  "style": "arduino_blocks"
};

const board_base_map = {
  "type": "board_base_map",
  "message0": "map %1 value to [ 0 - %2]",
  "args0": [
    {
      "type": "input_value",
      "name": "NUM",
      "check": "Number"
    },
    {
      "type": "input_value",
      "name": "DMAX",
      "check": "Number"
    }
  ],
  "inputsInline": true,
  "output": null,
  "tooltip": msgOptions.ARDUINO_BASE_MAP_TOOLTIP,
  "helpUrl": msgOptions.ARDUINO_BASE_MAP_HELPURL,
  "style": "arduino_blocks"
};
const board_base_inout_tone = {
  "type": "board_base_inout_tone",
  "message0": " emits sound on the pin %1 on frequency (Hz) %2",
  "args0": [
   
    {
      "type": "field_dropdown",
      "name": "PIN",
      "options": dropdownDigitalOptions
    },
    {
      "type": "input_value",
      "name": "NUM",
      "check": "Number"
    }
  ],
  "inputsInline": true,
  "previousStatement": null,
  "nextStatement": null,
  "tooltip": msgOptions.ARDUINO_TONE_TOOLTIP,
  "helpUrl": msgOptions.ARDUINO_TONE_HELPURL,
  "style": "arduino_blocks"
};

const board_base_inout_notone = {
  "type": "board_base_inout_notone",
  "message0": " stop sound on the pin %1",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "PIN",
      "options": dropdownDigitalOptions
    },
  ],
  "inputsInline": true,
  "previousStatement": null,
  "nextStatement": null,
  "tooltip": msgOptions.ARDUINO_NOTONE_TOOLTIP,
  "helpUrl": msgOptions.ARDUINO_NOTONE_HELPURL,
  "style": "arduino_blocks"
};


//board Serial block definition 



const board_serial_init = {
  "type": "board_serial_init",
  "message0": " serial communication init speed %1 ",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "SPEED",
      "options": serial,
    }
  ],
  "previousStatement": true,
  "nextStatement": true,
  "tooltip": "%{BKY_SERIAL_PRINT_TOOLTIP}",
  "helpUrl": "%{BKY_SERIAL_PRINT_HELPURL}",
  "style": "arduino_blocks",
  "inputsInline": true
};

const board_serial_printfor = {
  "type": "board_serial_printfor",
  "message0": "Print Format %1  %2",
  "args0": [
    {
      "type": "field_dropdown",
      "name": "TYPE",
       "options": [
        [msgOptions2.SERIAL_PRINT_FORDECIMAL, "DEC"],
        [msgOptions2.SERIAL_PRINT_FORHEXA, "HEX"],
        [msgOptions2.SERIAL_PRINT_FORBIN, "BIN"],
        [msgOptions2.SERIAL_PRINT_FOROCT, "OCT"],
       ]
    },
    {
      "type": "input_value",
      "name": "CONTENT",
      "check": "Number"
    }
  ],
  "previousStatement": true,
  "nextStatement": true,
  "tooltip": msgOptions.SERIAL_PRINT_TOOLTIP,
  "helpUrl": msgOptions.SERIAL_PRINT_HELPURL,
  "style": "arduino_blocks",
  "inputsInline": true
};

const board_serial_print = {
  "type": "board_serial_print",
  "message0": "Send the data to the serial port %1",
  "args0": [
    {
      "type": "input_value",
      "name": "CONTENT",
      "check": "Number"
    }
  ],
  "previousStatement": true,
  "nextStatement": true,
  "tooltip": msgOptions.SERIAL_PRINT_TOOLTIP,
  "helpUrl": msgOptions.SERIAL_PRINT_HELPURL,
  "style": "arduino_blocks"
};

const board_serial_available = {
  "type": "board_serial_available",
  "message0": "Serial Available",
  "inputsInline": true,
  "output": "Boolean",
  "tooltip": msgOptions.SERIAL_PRINT_TOOLTIP,
  "helpUrl": msgOptions.SERIAL_PRINT_HELPURL,
  "style": "arduino_blocks"
};

const board_serial_read = {
  "type": "board_serial_read",
  "message0": "Serial Read",
  "inputsInline": true,
  "output": "Number",
  "tooltip": msgOptions.SERIAL_PRINT_TOOLTIP,
  "helpUrl": msgOptions.SERIAL_PRINT_HELPURL,
  "style": "arduino_blocks"
};

const board_serial_readStringUntil = {
  "type": "board_serial_readStringUntil",
  "message0": " Read String Until %1",
  "args0": [
    {
      "type": "input_value",
      "name": "CONTENT",
      "check": "String"
    }
  ],
  "inputsInline": true,
  "output": "String",
  "tooltip": msgOptions.SERIAL_READSTRINGUNTIL_TOOLTIP,
  "helpUrl": msgOptions.SERIAL_READSTRINGUNTIL_HELPURL,
  "style": "arduino_blocks"
};

const board_serial_flush = {
  "type": "board_serial_flush",
  "message0": "Serial Flush",
  "previousStatement": true,
  "nextStatement": true,
  "tooltip": msgOptions.SERIAL_PRINT_TOOLTIP,
  "helpUrl": msgOptions.SERIAL_PRINT_HELPURL,
  "style": "arduino_blocks"
};





// Create the block definitions for the JSON-only blocks.
// This does not register their definitions with Blockly.
// This file has no side effects!
export const blocks = Blockly.common.createBlockDefinitionsFromJsonArray(

    [addText,
      board_base_inout_buildin_led,
      board_base_inout_digital_write,
      board_base_inout_notone,
      board_base_inout_tone,
      board_base_map,
      board_base_angle,
      board_base_delay,
      board_base_inout_analog_read,
      board_base_inout_analog_write,
      board_base_inout_highlow,
      board_base_inout_digital_read,
      ultrasonic_sensor,
      ir_Sensor,
      sensor3,
      sensor4,
      sensor5,
      motor,
      motor2,
      motor3,
      motor4,
      motor5,

      board_serial_flush,
      board_serial_readStringUntil,
      board_serial_read,
      board_serial_available,
      board_serial_print,
      board_serial_printfor,
      board_serial_init,

    ]);
