import profile from "./profile";

const digitalArray = profile.arduino_mega[0].digital;
const pwmArray = profile.arduino_mega[0].PWM;

// Create a flat dropdownDigital array for motor assignments with pin values
const dropdownDigitalMotor2 = [
  ["M3", pwmArray["8"]],
  ["M4", pwmArray["11"]],
];

export default dropdownDigitalMotor2;
