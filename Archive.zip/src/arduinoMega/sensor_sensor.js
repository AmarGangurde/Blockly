import profile from "./profile";

const digitalArray = profile.arduino_mega[0].digital;


const dropdownDigitalMotor = [
    ["S1", digitalArray["23"]],
    ["S2", digitalArray["25"]],
    ["S3", digitalArray["27"]],
    ["S4", digitalArray["29"]],
    ["S4", digitalArray["33"], digitalArray["35"]],
];
  
  export default dropdownDigitalMotor;