import profile from "./profile";

const digitalArray = profile.arduino_mega[0].digital;
const pwmArray = profile.arduino_mega[0].PWM;

// Create a flat dropdownDigital array for motor assignments with pin values
const dropdownDigitalMotor = [
  ["M1", digitalArray["2"]],  // Update this line
  ["M2", digitalArray["4"]],
];

export default dropdownDigitalMotor;
